"""Bounded ZIP listing/extraction. Canonical source for generated Office copies."""

import argparse
import json
import os
import shutil
import stat
import struct
import tempfile
import unicodedata
import uuid
import zipfile
import zlib
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path


class ArchiveError(ValueError):
    pass


@dataclass(frozen=True)
class Limits:
    archive_bytes: int = 100 * 1024 * 1024
    metadata_bytes: int = 4 * 1024 * 1024
    members: int = 4096
    member_bytes: int = 128 * 1024 * 1024
    total_bytes: int = 512 * 1024 * 1024
    path_bytes: int = 1024
    depth: int = 32


DEFAULT_LIMITS = Limits()
CHUNK = 64 * 1024
INCOMPLETE = ".metawork-archive-incomplete"
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {
    f"{prefix}{number}" for prefix in ("COM", "LPT") for number in range(1, 10)
}


def _directory_bounds(source, size, limits):
    # Bound the directory BEFORE ZipFile allocates its member objects. Do not
    # let ZIP64 override the small EOCD values after this check.
    source.seek(max(0, size - 65557))
    tail = source.read(65557)
    at = tail.rfind(b"PK\x05\x06")
    if at < 0 or len(tail) - at < 22:
        raise ArchiveError("Missing ZIP directory")
    record = struct.unpack("<4s4H2LH", tail[at:at + 22])
    _, disk, directory_disk, disk_count, count, length, offset, comment = record
    absolute = size - len(tail) + at
    if disk or directory_disk or disk_count != count:
        raise ArchiveError("Multi-disk ZIP is unsupported")
    if count == 65535 or length == 0xffffffff or offset == 0xffffffff:
        raise ArchiveError("ZIP64 is unsupported")
    if absolute >= 20:
        source.seek(absolute - 20)
        if source.read(4) == b"PK\x06\x07":
            raise ArchiveError("ZIP64 is unsupported")
    if absolute + 22 + comment != size or offset + length != absolute:
        raise ArchiveError("Invalid ZIP directory bounds")
    if count > limits.members or length + comment > limits.metadata_bytes:
        raise ArchiveError("ZIP member or metadata budget exceeded")
    source.seek(offset)
    raw = source.read(length)
    cursor, actual = 0, 0
    while cursor < len(raw):
        if len(raw) - cursor < 46 or raw[cursor:cursor + 4] != b"PK\x01\x02":
            raise ArchiveError("Invalid ZIP directory entry")
        names, extras, comments = struct.unpack_from("<3H", raw, cursor + 28)
        cursor += 46 + names + extras + comments
        actual += 1
        if cursor > len(raw) or actual > limits.members:
            raise ArchiveError("Actual ZIP member or metadata budget exceeded")
    if cursor != length or actual != count:
        raise ArchiveError("ZIP directory member count mismatch")
    return offset, count, length + comment


def _member_path(info, limits):
    name = info.orig_filename
    if name != info.filename or "\\" in name or name.startswith("/"):
        raise ArchiveError("Unsafe ZIP path")
    parts = (name[:-1] if name.endswith("/") else name).split("/")
    if parts[0].casefold() == INCOMPLETE:
        raise ArchiveError("Reserved extraction marker")
    if not name or len(parts) > limits.depth or len(name.encode("utf-8")) > limits.path_bytes:
        raise ArchiveError("ZIP path budget exceeded")
    for part in parts:
        if (not part or part in (".", "..") or part != part.rstrip(" .")
                or any(ord(c) < 32 or ord(c) == 127 or c in '<>:"|?*' for c in part)
                or part.split(".")[0].upper() in RESERVED):
            raise ArchiveError("Unsafe ZIP path component")
    mode = stat.S_IFMT(info.external_attr >> 16)
    if mode not in (0, stat.S_IFREG, stat.S_IFDIR) or info.external_attr & 0x400:
        raise ArchiveError("ZIP links and special entries are unsupported")
    if info.flag_bits & 1 or info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
        raise ArchiveError("Encrypted or unsupported ZIP compression")
    # The old Unix extra field can encode a link target; never materialize it.
    extra = info.extra
    while extra:
        if len(extra) < 4:
            raise ArchiveError("Invalid ZIP extra field")
        kind, length = struct.unpack("<HH", extra[:4])
        if length > len(extra) - 4 or kind == 1 or (kind == 0x000d and length > 12):
            raise ArchiveError("ZIP64, link or invalid extra field")
        extra = extra[4 + length:]
    if info.is_dir() and info.file_size:
        raise ArchiveError("ZIP directory contains data")
    return Path(*(unicodedata.normalize("NFC", part) for part in parts))


@contextmanager
def _archive(filename, limits):
    path = Path(filename)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > limits.archive_bytes:
        raise ArchiveError("Input must be a regular file within the archive budget")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    with os.fdopen(os.open(path, flags), "rb") as source:
        opened = os.fstat(source.fileno())
        if (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns) != (
                before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns):
            raise ArchiveError("ZIP input changed")
        directory, count, metadata = _directory_bounds(source, opened.st_size, limits)
        with zipfile.ZipFile(source) as archive:
            infos = archive.infolist()
            if len(infos) != count:
                raise ArchiveError("ZIP directory member count mismatch")
            entries, seen, prefixes, ranges = [], set(), {}, []
            declared = 0
            for info in infos:
                member = _member_path(info, limits)
                key = str(member).casefold()
                if key in seen:
                    raise ArchiveError("Duplicate ZIP destination")
                seen.add(key)
                for depth in range(1, len(member.parts) + 1):
                    prefix = str(Path(*member.parts[:depth]))
                    folded = prefix.casefold()
                    if folded in prefixes and prefixes[folded] != prefix:
                        raise ArchiveError("ZIP path alias collision")
                    prefixes[folded] = prefix
                declared += info.file_size
                if info.file_size > limits.member_bytes or declared > limits.total_bytes:
                    raise ArchiveError("Declared ZIP byte budget exceeded")
                # Check the local header and compressed slice, then decompress
                # ourselves so lying file_size fields cannot truncate expansion.
                source.seek(info.header_offset)
                header = source.read(30)
                if len(header) != 30 or header[:4] != b"PK\x03\x04":
                    raise ArchiveError("Invalid ZIP local header")
                fields = struct.unpack("<4s5H3L2H", header)
                flags, compression, name_length, extra_length = fields[2], fields[3], fields[-2], fields[-1]
                if flags != info.flag_bits or compression != info.compress_type:
                    raise ArchiveError("ZIP local header mismatch")
                metadata += 30 + name_length + extra_length
                if metadata > limits.metadata_bytes:
                    raise ArchiveError("ZIP local metadata budget exceeded")
                raw_name = source.read(name_length)
                if raw_name.decode("utf-8" if flags & 0x800 else "cp437") != info.orig_filename:
                    raise ArchiveError("ZIP local filename mismatch")
                start = info.header_offset + 30 + name_length + extra_length
                end = start + info.compress_size
                if info.header_offset < 0 or end > directory:
                    raise ArchiveError("ZIP compressed slice exceeds data region")
                ranges.append((info.header_offset, end))
                entries.append((info, member, start))
            previous = 0
            for start, end in sorted(ranges):
                if start < previous:
                    raise ArchiveError("Overlapping ZIP entries")
                previous = end
            yield source, entries
        after = os.fstat(source.fileno())
        if (after.st_size, after.st_mtime_ns, after.st_ctime_ns) != (
                opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns):
            raise ArchiveError("ZIP input changed during processing")


def _chunks(source, info, start):
    source.seek(start)
    remaining = info.compress_size
    decoder = zlib.decompressobj(-15) if info.compress_type == zipfile.ZIP_DEFLATED else None
    while remaining:
        chunk = source.read(min(CHUNK, remaining))
        if not chunk:
            raise ArchiveError("Truncated ZIP payload")
        remaining -= len(chunk)
        if decoder is None:
            yield chunk
        else:
            while chunk:
                output = decoder.decompress(chunk, CHUNK)
                chunk = decoder.unconsumed_tail
                if decoder.unused_data:
                    raise ArchiveError("Trailing ZIP compressed data")
                if output:
                    yield output
    if decoder is not None:
        while not decoder.eof:
            output = decoder.decompress(b"", CHUNK)
            if not output:
                raise ArchiveError("Incomplete ZIP compressed stream")
            yield output


def list_archive(filename, offset=0, limit=100, limits=DEFAULT_LIMITS):
    if offset < 0 or not 1 <= limit <= 100:
        raise ArchiveError("Invalid listing page")
    with _archive(filename, limits) as (_, entries):
        return {
            "members": len(entries),
            "declaredBytes": sum(info.file_size for info, _, _ in entries),
            "entries": [{"name": info.orig_filename, "size": info.file_size, "directory": info.is_dir()}
                        for info, _, _ in entries[offset:offset + limit]],
            "nextOffset": offset + limit if offset + limit < len(entries) else None,
        }


def read_member(filename, name, limits=DEFAULT_LIMITS):
    """Read one checked member; never trust ZipFile's declared size to bound it."""
    with _archive(filename, limits) as (source, entries):
        for info, _, start in entries:
            if info.orig_filename != name or info.is_dir():
                continue
            content = bytearray()
            crc = 0
            for chunk in _chunks(source, info, start):
                if len(content) + len(chunk) > min(limits.member_bytes, limits.total_bytes):
                    raise ArchiveError("Actual ZIP decompressed-byte budget exceeded")
                content.extend(chunk)
                crc = zlib.crc32(chunk, crc)
            if len(content) != info.file_size or crc != info.CRC:
                raise ArchiveError("ZIP payload size or CRC mismatch")
            return bytes(content)
        raise KeyError(name)


def check_archive(filename, limits=DEFAULT_LIMITS):
    """Validate every payload without materializing an extraction tree."""
    total = 0
    with _archive(filename, limits) as (source, entries):
        for info, _, start in entries:
            size, crc = 0, 0
            for chunk in _chunks(source, info, start):
                size += len(chunk)
                total += len(chunk)
                if size > limits.member_bytes or total > limits.total_bytes:
                    raise ArchiveError("Actual ZIP decompressed-byte budget exceeded")
                crc = zlib.crc32(chunk, crc)
            if size != info.file_size or crc != info.CRC:
                raise ArchiveError("ZIP payload size or CRC mismatch")


@contextmanager
def checked_copy(filename, limits=DEFAULT_LIMITS):
    """Give third-party consumers the same private bytes that were checked."""
    with tempfile.TemporaryDirectory(prefix="metawork-office-input-") as directory:
        target = Path(directory) / ("input" + Path(filename).suffix)
        with _archive(filename, limits) as (source, _):
            source.seek(0)
            copied = 0
            with target.open("xb") as output:
                while chunk := source.read(CHUNK):
                    copied += len(chunk)
                    if copied > limits.archive_bytes:
                        raise ArchiveError("Actual ZIP archive-byte budget exceeded")
                    output.write(chunk)
        check_archive(target, limits)
        yield target


@contextmanager
def temporary_extract(filename, limits=DEFAULT_LIMITS):
    """Own the checked extraction until its consumer finishes, including failure."""
    with tempfile.TemporaryDirectory(prefix="metawork-office-") as directory:
        root = Path(directory).resolve()
        output = root / "content"
        safe_extract(filename, output, limits, workspace=root)
        yield output


def safe_extract(filename, output, limits=DEFAULT_LIMITS, *, workspace=None):
    # An explicit base makes normal calls independent of shell cd. This is a
    # caller-supplied path relation, not immutable Task authority or a sandbox.
    workspace = Path(workspace).resolve(strict=True) if workspace is not None else Path.cwd().resolve()
    output = Path(output)
    if not output.is_absolute():
        output = workspace / output
    parent = output.parent.resolve(strict=True)
    parent.relative_to(workspace)
    output = parent / output.name
    relative = output.relative_to(workspace)
    if (not relative.parts or output.name.casefold() in (".", "..", "skills") or output.name != output.name.rstrip(" .")
            or "\\" in output.name or ":" in output.name
            or any(part.casefold() in (".agents", ".claude", ".codex") for part in relative.parts)):
        raise ArchiveError("Extraction requires a fresh workspace data child")
    created = False
    try:
        with _archive(filename, limits) as (source, entries):
            output.mkdir(mode=0o700)  # Exclusive: never merge with existing data.
            created = True
            marker = output / INCOMPLETE
            marker.write_text("Extraction has not completed. Do not consume or reuse this directory.\n", encoding="utf-8")
            total = 0
            for info, member, start in entries:
                target = output / member
                target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                if info.is_dir():
                    target.mkdir(exist_ok=True, mode=0o700)
                    destination = None
                else:
                    destination = target.open("xb")
                size, crc = 0, 0
                try:
                    for chunk in _chunks(source, info, start):
                        size += len(chunk)
                        total += len(chunk)
                        if size > limits.member_bytes or total > limits.total_bytes:
                            raise ArchiveError("Actual ZIP decompressed-byte budget exceeded")
                        crc = zlib.crc32(chunk, crc)
                        if destination is not None:
                            destination.write(chunk)
                    if size != info.file_size or crc != info.CRC:
                        raise ArchiveError("ZIP payload size or CRC mismatch")
                finally:
                    if destination is not None:
                        destination.close()
            result = {"directory": str(output), "members": len(entries), "bytes": total}
        marker.unlink()
        return result
    except BaseException:
        if created:
            shutil.rmtree(output)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("list", "extract"))
    parser.add_argument("archive")
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--output")
    parser.add_argument("--workspace", help="Explicit extraction base; not an authority grant")
    args = parser.parse_args()
    try:
        result = list_archive(args.archive, args.offset, args.limit) if args.operation == "list" else safe_extract(
            args.archive, args.output or f"zip-data-{uuid.uuid4().hex}", workspace=args.workspace)
        print(json.dumps(result, ensure_ascii=True))
    except Exception as error:
        parser.exit(1, f"Archive rejected: {error}\n")


if __name__ == "__main__":
    main()
