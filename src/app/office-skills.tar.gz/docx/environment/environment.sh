case "$(/usr/bin/uname -m)" in
arm64)
OFFICE_NAMESPACE='MetaWork/OfficeDependencies'
METAWORK_OFFICE_TARGET='macos-aarch64'
PYTHON_ID='3fcaa12b9cc3ae97a939a13cfd40f58896c5113a66a901b435459424f4ceb441'
PYTHON_URL='https://github.com/astral-sh/python-build-standalone/releases/download/20260901/cpython-3.13.15%2B20260901-aarch64-apple-darwin-install_only.tar.gz'
PYTHON_SHA='b9054a9d3d54f4cb5573d44907fddb29874b08909bde73f29f2868cf872223ee'
NODE_ID='2ee0e6c06ce6718e70ce8bdb08dc29a85cce2e454e57ca7afa53edad21df02c1'
NODE_URL='https://nodejs.org/dist/v22.23.4/node-v22.23.4-darwin-arm64.tar.gz'
NODE_SHA='c9e1dbc748b33ed2d14f42445191ecaf14c56259c7a9a26d0042c49ec2b66428'
NODE_FOLDER='node-v22.23.4-darwin-arm64'
PYTHON_EXE='python/bin/python3.13'
NODE_EXE='node-v22.23.4-darwin-arm64/bin/node'
;;
x86_64)
OFFICE_NAMESPACE='MetaWork/OfficeDependencies'
METAWORK_OFFICE_TARGET='macos-x86_64'
PYTHON_ID='6462dacd098a3e9e9a85b1d90991b695b9b72cf85508e4e78b98ad40890931b9'
PYTHON_URL='https://github.com/astral-sh/python-build-standalone/releases/download/20260901/cpython-3.13.15%2B20260901-x86_64-apple-darwin-install_only.tar.gz'
PYTHON_SHA='49f0d97f506b855eed60b74a8ac138595c5b39799a6aa5e0d7ca8abe1019a4d4'
NODE_ID='5887423a897586bba2fa1530418b6a84a95a4cc2fac4ebeeb8ec09b566231591'
NODE_URL='https://nodejs.org/dist/v22.23.4/node-v22.23.4-darwin-x64.tar.gz'
NODE_SHA='efcc2b0db6f94bf53eddb038fe2b370277a042bd29e4f19b8f8e23598795b819'
NODE_FOLDER='node-v22.23.4-darwin-x64'
PYTHON_EXE='python/bin/python3.13'
NODE_EXE='node-v22.23.4-darwin-x64/bin/node'
;;
*) echo "Unsupported Office target" >&2; exit 2 ;;
esac
export METAWORK_OFFICE_TARGET
