@if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" goto office_arm64
@if /i not "%PROCESSOR_ARCHITECTURE%"=="AMD64" exit /b 2
@set "OFFICE_NAMESPACE=MetaWork/OfficeDependencies"
@set "PYTHON_ID=bd948c50c30962f7f7703b852233b9ec4f98859d7b8a0dc218d311a7b41ad89c"
@set "PYTHON_URL=https://api.nuget.org/v3-flatcontainer/python/3.13.15/python.3.13.15.nupkg"
@set "PYTHON_SHA=05357887df50d3153efc681bdf432c321d3e2f9ce5788f99f4515b27e8fda0ac"
@set "NODE_ID=b7046de901f3a4d91ffa2c5b4ec5b2706bf2ab4d27f9f698405ae5204179e4d8"
@set "NODE_URL=https://nodejs.org/dist/v24.19.0/node-v24.19.0-win-x64.zip"
@set "NODE_SHA=57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73"
@set "NODE_FOLDER=node-v24.19.0-win-x64"
@set "PYTHON_EXE=tools/python.exe"
@set "NODE_EXE=node-v24.19.0-win-x64/node.exe"
@exit /b 0
:office_arm64
@set "OFFICE_NAMESPACE=MetaWork/OfficeDependencies"
@set "PYTHON_ID=d8aef8294c92982cef8e8f6471cb21b4fd7d996732a6155a6fabec8f2212b7c9"
@set "PYTHON_URL=https://api.nuget.org/v3-flatcontainer/pythonarm64/3.13.15/pythonarm64.3.13.15.nupkg"
@set "PYTHON_SHA=3c1b1fdf56adc14634165df922d447520aefdc4a8411a34c34d8a062a4edf494"
@set "NODE_ID=6116569f73d5c84a0483feb031de837fad897402a12f75ddffe8c1baf6a3c9a7"
@set "NODE_URL=https://nodejs.org/dist/v24.19.0/node-v24.19.0-win-arm64.zip"
@set "NODE_SHA=8502f4a50b458d4cc38ed8f2001556c2cd239d464920f74017926ccb1e1c157f"
@set "NODE_FOLDER=node-v24.19.0-win-arm64"
@set "PYTHON_EXE=tools/python.exe"
@set "NODE_EXE=node-v24.19.0-win-arm64/node.exe"
@exit /b 0
