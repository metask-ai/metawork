---
name: pptx
description: Create, read, edit, combine, split, and refine PowerPoint presentations. Use for .pptx files, slides, decks, presentations, templates, layouts, speaker notes, comments, and extracting presentation content.
---

# PPTX Skill

## Execution environment

Use only this Skill's fixed private runtimes. Match the native OS and architecture to the generated table below. The fixed prepare/run entry selects the native target automatically; no target argument is accepted. Read the download estimate directly from this table. Use Read if additional [environment input](environment/environment.json) details are needed before preparation; never choose an interpreter from PATH or infer paths from this Skill's parent directory.

Before continuing Office work in a new user message, including a request to continue or revise a file, invoke this Skill again and use the absolute resource directory returned by that invocation. Materialized activation paths are temporary; do not reuse a path from an earlier message. If a remembered path is unavailable, reacquire the Skill once. If reacquiring fails, report the Skill/resource failure rather than preparing at the old path, searching its parent directories or treating it as a missing private runtime. Reacquiring the Skill does not grant download consent or tool permissions.

| Native platform | Input target key | Python payload bytes | Node payload bytes |
| --- | --- | ---: | ---: |
| Windows x64 | `windows-x86_64` | 25921381 | 40361909 |
| Windows arm64 | `windows-aarch64` | 20284084 | 36520636 |
| macOS arm64 | `macos-aarch64` | 38927650 | 53053926 |
| macOS x64 | `macos-x86_64` | 35296237 | 54247771 |

| Platform | Fixed prepare entry | Fixed run entry |
| --- | --- | --- |
| Windows | `"${CLAUDE_SKILL_DIR}/environment/prepare.cmd" python` or `node` | `"${CLAUDE_SKILL_DIR}/environment/run.cmd" python script.py [arguments]` or `node script.cjs [arguments]` |
| macOS | `/bin/sh "${CLAUDE_SKILL_DIR}/environment/prepare.sh" python` or `node` | `/bin/sh "${CLAUDE_SKILL_DIR}/environment/run.sh" python script.py [arguments]` or `node script.cjs [arguments]` |

Use the existing Shell with each argument quoted separately. Resource files need no executable bit. Examples below using `run.cmd` mean the selected absolute run entry above; on macOS always substitute `/bin/sh "${CLAUDE_SKILL_DIR}/environment/run.sh"`. Do not execute `.cmd` on macOS or use a system Node/Python.

Run never downloads. Use it to perform the needed operation and detect a missing environment. Before first preparation, explain the purpose and the matching row's Python or Node payload bytes, then obtain the user's agreement. These totals include interpreter and locked library payloads; indexes, retries and transport overhead are extra, so present an estimated network download. Prepare may download: call it only after consent has been obtained, even for an intended reuse. No arbitrary URL, version, package or root arguments are accepted. Allow 30 minutes per runtime download, 10 minutes for dependency installation and bounded final checks; observe long work through the existing Shell background/output tools.

On macOS, **fresh Node preparation requires the exact private Python already prepared**. It does not download Python implicitly. When Node and its prerequisite are missing, explain their combined download and prepare Python, then Node, after agreement. XLSX-only Python work needs no Node. Completed Node can be reused and run without Python; Python validation or reading of documents separately needs Python. Windows keeps both languages independently preparable. Download agreement does not grant filesystem or Shell permissions: follow the existing approval mechanism if the shared root is outside the Workspace, and explain refusals without changing roots. `full_access` adds no product installation gate.

Environments are shared at `%LOCALAPPDATA%/MetaWork/OfficeDependencies` on Windows and `$HOME/Library/Application Support/MetaWork/OfficeDependencies` on macOS. Do not update, rename, delete or repair completed environments. If an existing directory fails checks, report it unavailable with the exact path from prepare. Explain manual recovery: stop every Task and external script using that directory, exit MetaWork, and confirm no consumers remain. Only then may the user explicitly choose to remove that one directory, reopen MetaWork and agree to preparing again. Never remove the parent, other environments, resources or documents. Rename success does not prove no consumers remain. Preserve interrupted stages whose descendants are not confirmed stopped. Do not install globally, change user package configuration, switch architectures or fall back to system packages. Private dependencies are not a sandbox.

Write scripts, working copies and outputs in the Task Workspace. Use `from office_archive import checked_copy` and load only its private checked path inside the context when passing an existing Office file to a library. Never overwrite an attachment original.

This edition cannot render, export PDF, accept revisions or recalculate formulas. Do not invent visual QA or calculation results. XLSX may request recalculation on open; this does not calculate or populate caches now.

## Read, check and deliver

For bounded structured text, use the selected run entry with `python "${CLAUDE_SKILL_DIR}/environment/read.py" input.docx new-content.json` (also XLSX/PPTX). For XML work, run `scripts/office/` helpers through that same Python entry, using new output directories. Reopen changed content and validate supported structures. Report unsupported features and checks not performed.

Call the Host tool `DeliverFile` with the actual Task Workspace-relative output path, for example `{"path":"results/report.docx"}`. This is a tool call, not a Shell command or text to print. Deliver finished requested files, not temporary XML, scripts or check output.

## Workflows

- Create with the fixed PptxGenJS library: read [pptxgenjs.md](pptxgenjs.md), save a script and execute `run.cmd node create.cjs`. Save the generator output to a new intermediate file, then follow [creation checks](creation-checks.md) to produce and strictly check the delivery candidate.
- Read or edit an existing file: read [editing.md](editing.md), inspect structured text and checked XML, then make focused changes on a working copy.
- Validate and reopen the finished file, checking slide order, text, notes, relationships and changed structures. Visual inspection and rendering are unavailable; say so explicitly.

## Design Ideas

**Don't create boring slides.** Plain bullets on a white background won't impress anyone. Consider ideas from this list for each slide.

### Before Starting

- **Pick a bold, content-informed color palette**: The palette should feel designed for THIS topic. If swapping your colors into a completely different presentation would still "work," you haven't made specific enough choices.
- **Dominance over equality**: One color should dominate (60-70% visual weight), with 1-2 supporting tones and one sharp accent. Never give all colors equal weight.
- **Dark/light contrast**: Dark backgrounds for title + conclusion slides, light for content ("sandwich" structure). Or commit to dark throughout for a premium feel.
- **Commit to a visual motif**: Pick ONE distinctive element and repeat it — rounded image frames, icons in colored circles, thick single-side borders. Carry it across every slide.

### Color Palettes

Choose colors that match your topic — don't default to generic blue. Use these palettes as inspiration:

| Theme | Primary | Secondary | Accent |
|-------|---------|-----------|--------|
| **Midnight Executive** | `1E2761` (navy) | `CADCFC` (ice blue) | `FFFFFF` (white) |
| **Forest & Moss** | `2C5F2D` (forest) | `97BC62` (moss) | `F5F5F5` (cream) |
| **Coral Energy** | `F96167` (coral) | `F9E795` (gold) | `2F3C7E` (navy) |
| **Warm Terracotta** | `B85042` (terracotta) | `E7E8D1` (sand) | `A7BEAE` (sage) |
| **Ocean Gradient** | `065A82` (deep blue) | `1C7293` (teal) | `21295C` (midnight) |
| **Charcoal Minimal** | `36454F` (charcoal) | `F2F2F2` (off-white) | `212121` (black) |
| **Teal Trust** | `028090` (teal) | `00A896` (seafoam) | `02C39A` (mint) |
| **Berry & Cream** | `6D2E46` (berry) | `A26769` (dusty rose) | `ECE2D0` (cream) |
| **Sage Calm** | `84B59F` (sage) | `69A297` (eucalyptus) | `50808E` (slate) |
| **Cherry Bold** | `990011` (cherry) | `FCF6F5` (off-white) | `2F3C7E` (navy) |

### For Each Slide

**Every slide needs a visual element** — image, chart, icon, or shape. Text-only slides are forgettable.

**Layout options:**
- Two-column (text left, illustration on right)
- Icon + text rows (icon in colored circle, bold header, description below)
- 2x2 or 2x3 grid (image on one side, grid of content blocks on other)
- Half-bleed image (full left or right side) with content overlay

**Data display:**
- Large stat callouts (big numbers 60-72pt with small labels below)
- Comparison columns (before/after, pros/cons, side-by-side options)
- Timeline or process flow (numbered steps, arrows)

**Visual polish:**
- Icons in small colored circles next to section headers
- Italic accent text for key stats or taglines

### Typography

**Choose an interesting font pairing** — don't default to Arial. Pick a header font with personality and pair it with a clean body font.

| Header Font | Body Font |
|-------------|-----------|
| Georgia | Calibri |
| Arial Black | Arial |
| Calibri | Calibri Light |
| Cambria | Calibri |
| Trebuchet MS | Calibri |
| Impact | Arial |
| Palatino | Garamond |
| Consolas | Calibri |

| Element | Size |
|---------|------|
| Slide title | 36-44pt bold |
| Section header | 20-24pt bold |
| Body text | 14-16pt |
| Captions | 10-12pt muted |

### Spacing

- 0.5" minimum margins
- 0.3-0.5" between content blocks
- Leave breathing room—don't fill every inch

### Avoid (Common Mistakes)

- **Don't repeat the same layout** — vary columns, cards, and callouts across slides
- **Don't center body text** — left-align paragraphs and lists; center only titles
- **Don't skimp on size contrast** — titles need 36pt+ to stand out from 14-16pt body
- **Don't default to blue** — pick colors that reflect the specific topic
- **Don't mix spacing randomly** — choose 0.3" or 0.5" gaps and use consistently
- **Don't style one slide and leave the rest plain** — commit fully or keep it simple throughout
- **Don't create text-only slides** — add images, icons, charts, or visual elements; avoid plain title + bullets
- **Don't forget text box padding** — when aligning lines or shapes with text edges, set `margin: 0` on the text box or offset the shape to account for padding
- **Don't use low-contrast elements** — icons AND text need strong contrast against the background; avoid light text on light backgrounds or dark text on dark backgrounds
- **NEVER use accent lines under titles** — these are a hallmark of AI-generated slides; use whitespace or background color instead

---

