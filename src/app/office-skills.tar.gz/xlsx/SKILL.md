---
name: xlsx
description: Create, read, edit, clean, and format spreadsheets with formulas and saved values. Use for .xlsx, .csv, .tsv, Excel, formulas, charts, tabular data, financial models, and spreadsheet deliverables. Do not use for Word documents or Google Sheets API integration.
---

# XLSX creation, editing and analysis

## Execution environment

Use only this Skill's fixed private runtimes. Match the native OS and architecture to the generated table below. The fixed prepare/run entry selects the native target automatically; no target argument is accepted. Read the download estimate directly from this table. Use Read if additional [environment input](environment/environment.json) details are needed before preparation; never choose an interpreter from PATH or infer paths from this Skill's parent directory.

| Native platform | Input target key | Python payload bytes | Node payload bytes |
| --- | --- | ---: | ---: |
| Windows x64 | `windows-x86_64` | 25921381 | 40361909 |
| Windows arm64 | `windows-aarch64` | 20284084 | 36520636 |
| macOS arm64 | `macos-aarch64` | 38927650 | 53053926 |
| macOS x64 | `macos-x86_64` | 35296237 | 54247771 |

| Platform | Fixed prepare entry | Fixed run entry |
| --- | --- | --- |
| Windows | `"${CLAUDE_SKILL_DIR}/environment/prepare.cmd" python` or `node` | `"${CLAUDE_SKILL_DIR}/environment/run.cmd" python script.py [arguments]` or `node script.cjs [arguments]` |
| macOS | `/bin/sh "${CLAUDE_SKILL_DIR}/environment/prepare.sh" python` or `node` | `/bin/sh "${CLAUDE_SKILL_DIR}/environment/run.sh" python script.py [arguments]` or `node script.cjs [arguments]` |

Use the existing Shell with each argument quoted separately. Resource files need no executable bit. Examples below using `run.cmd` mean the selected absolute run entry above; on macOS always substitute `/bin/sh "${CLAUDE_SKILL_DIR}/environment/run.sh"`. Do not execute `.cmd` on macOS or use a system Node/Python.

Run never downloads. Use it to perform the needed operation and detect a missing environment. Before first preparation, explain the purpose and the matching row's Python or Node payload bytes, then obtain the user's agreement. These totals include interpreter and locked library payloads; indexes, retries and transport overhead are extra, so present an estimated network download. Prepare may download: call it only after consent has been obtained, even for an intended reuse. No arbitrary URL, version, package or root arguments are accepted. Allow 30 minutes per runtime download, 10 minutes for dependency installation and bounded final checks; observe long work through the existing Shell background/output tools.

On macOS, **fresh Node preparation requires the exact private Python already prepared**. It does not download Python implicitly. When Node and its prerequisite are missing, explain their combined download and prepare Python, then Node, after agreement. XLSX-only Python work needs no Node. Completed Node can be reused and run without Python; Python validation or reading of documents separately needs Python. Windows keeps both languages independently preparable. Download agreement does not grant filesystem or Shell permissions: follow the existing approval mechanism if the shared root is outside the Workspace, and explain refusals without changing roots. `full_access` adds no product installation gate.

Environments are shared at `%LOCALAPPDATA%/MetaWork/OfficeDependencies` on Windows and `$HOME/Library/Application Support/MetaWork/OfficeDependencies` on macOS. Do not update, rename, delete or repair completed environments. If an existing directory fails checks, report it unavailable with the exact path from prepare. Explain manual recovery: stop every Task and external script using that directory, exit MetaWork, and confirm no consumers remain. Only then may the user explicitly choose to remove that one directory, reopen MetaWork and agree to preparing again. Never remove the parent, other environments, resources or documents. Rename success does not prove no consumers remain. Preserve interrupted stages whose descendants are not confirmed stopped. Do not install globally, change user package configuration, switch architectures or fall back to system packages. Private dependencies are not a sandbox.

Write scripts, working copies and outputs in the Task Workspace. Use `from office_archive import checked_copy` and load only its private checked path inside the context when passing an existing Office file to a library. Never overwrite an attachment original.

This edition cannot render, export PDF, accept revisions or recalculate formulas. Do not invent visual QA or calculation results. XLSX may request recalculation on open; this does not calculate or populate caches now.

## Read, check and deliver

For bounded structured text, use the selected run entry with `python "${CLAUDE_SKILL_DIR}/environment/read.py" input.docx new-content.json` (also XLSX/PPTX). For XML work, run `scripts/office/` helpers through that same Python entry, using new output directories. Reopen changed content and validate supported structures. Report unsupported features and checks not performed.

Call the Host tool `DeliverFile` with the actual Task Workspace-relative output path, for example `{"path":"results/report.docx"}`. This is a tool call, not a Shell command or text to print. Deliver finished requested files, not temporary XML, scripts or check output.

# Requirements for Outputs

## All Excel files

### Professional Font
- Use a consistent, professional font (e.g., Arial, Times New Roman) for all deliverables unless otherwise instructed by the user

### Formula checks
- Inspect formula strings, references and any saved error values (#REF!, #DIV/0!, #VALUE!, #N/A, #NAME?). This runtime cannot evaluate formulas; report absent or stale caches and do not claim a zero-error recalculation.

### Preserve Existing Templates (when updating templates)
- Study and EXACTLY match existing format, style, and conventions when modifying files
- Never impose standardized formatting on files with established patterns
- Existing template conventions ALWAYS override these guidelines

## Financial models

### Color Coding Standards
Unless otherwise stated by the user or existing template

#### Industry-Standard Color Conventions
- **Blue text (RGB: 0,0,255)**: Hardcoded inputs, and numbers users will change for scenarios
- **Black text (RGB: 0,0,0)**: ALL formulas and calculations
- **Green text (RGB: 0,128,0)**: Links pulling from other worksheets within same workbook
- **Red text (RGB: 255,0,0)**: External links to other files
- **Yellow background (RGB: 255,255,0)**: Key assumptions needing attention or cells that need to be updated

### Number Formatting Standards

#### Required Format Rules
- **Years**: Format as text strings (e.g., "2024" not "2,024")
- **Currency**: Use $#,##0 format; ALWAYS specify units in headers ("Revenue ($mm)")
- **Zeros**: Use number formatting to make all zeros "-", including percentages (e.g., "$#,##0;($#,##0);-")
- **Percentages**: Default to 0.0% format (one decimal)
- **Multiples**: Format as 0.0x for valuation multiples (EV/EBITDA, P/E)
- **Negative numbers**: Use parentheses (123) not minus -123

### Formula Construction Rules

#### Assumptions Placement
- Place ALL assumptions (growth rates, margins, multiples, etc.) in separate assumption cells
- Use cell references instead of hardcoded values in formulas
- Example: Use =B5*(1+$B$6) instead of =B5*1.05

#### Formula Error Prevention
- Verify all cell references are correct
- Check for off-by-one errors in ranges
- Ensure consistent formulas across all projection periods
- Test with edge cases (zero values, negative numbers)
- Verify no unintended circular references

#### Documentation Requirements for Hardcodes
- Comment or in cells beside (if end of table). Format: "Source: [System/Document], [Date], [Specific Reference], [URL if applicable]"
- Examples:
  - "Source: Company 10-K, FY2024, Page 45, Revenue Note, [SEC EDGAR URL]"
  - "Source: Company 10-Q, Q2 2025, Exhibit 99.1, [SEC EDGAR URL]"
  - "Source: Bloomberg Terminal, 8/15/2025, AAPL US Equity"
  - "Source: FactSet, 8/20/2025, Consensus Estimates Screen"

## Working with openpyxl

Use the fixed openpyxl library for data, formulas, styles, tables and supported charts. Pandas, NumPy and XlsxWriter are not part of this Skill.

```python
from pathlib import Path
from openpyxl import Workbook, load_workbook
from openpyxl.workbook.properties import CalcProperties
from office_archive import checked_copy

with checked_copy("input.xlsx") as checked:
    workbook = load_workbook(checked, data_only=False)
    sheet = workbook.active
    sheet["C2"] = "=SUM(A2:B2)"
    workbook.calculation = CalcProperties(fullCalcOnLoad=True, forceFullCalc=True)
    workbook.save("updated.xlsx")
    workbook.close()
```

For new workbooks start with Workbook(), save to a new output and reopen to check values, formula text and styles. Prefer formulas for derived values. Cached values may be absent or stale; data_only=True does not calculate. Bound dense iteration for sparse worksheets. Preserve templates and disclose features a library cannot retain; do not silently claim full fidelity.
